<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<pre>
<h2><a href="./update/">自动更新NextIM</a></h2>
</pre>


<pre>
<h2><a href="./install/">重新安装NextIM</a></h2>
</pre>




</html>
