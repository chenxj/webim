<?php
var_dump(  split("/webim/install" ,  dirname(__FILE__) )   );

?>

