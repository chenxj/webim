<?php
include_once('../config.php');
echo "{\"version\":\"".$_IMC['version']."\"}";
?>
