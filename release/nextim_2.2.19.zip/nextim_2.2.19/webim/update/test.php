<?php
require('check.php');
echo '</br>';
require('version_info.php');
echo '</br>';
require('download_list.php');
echo '</br>';
require('update.php');
require('common.php');
?>
